package com.jsp.BANK_MANAGEMENT.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.BANK_MANAGEMENT.DTO.Bank;
import com.jsp.BANK_MANAGEMENT.REPOSITORY.BankRepository;

@Repository
public class BankDao 
{
	@Autowired
	BankRepository repository;
	
	public Bank CreateBank(Bank bank)
	{
		return repository.save(bank);
	}
	
	public Bank getBankDetails(int id)
	{
		Optional<Bank> b =repository.findById(id);
		if(b.isPresent())
		{
			return b.get();
		}
		else
		return null;
	}

	public List<Bank> getAllBankDetails()
	{
		return repository.findAll();
	}
	
	public String updateBankName(int id)
	{
		Bank b=getBankDetails(id);
		if(b!=null)
		{
			b.setBank_name("IDFC");
			repository.save(b);
			return "Updaten name sucessfully...";
		}return "Invalid id..";
	}
	
	public String deleteBank(int id)
	{
		Bank b=getBankDetails(id);
		if(b!=null)
		{
			repository.delete(b);
			return "deleted bank succesfully...";
		}return "invalid id...";
	}
}
