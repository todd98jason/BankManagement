package com.jsp.BANK_MANAGEMENT.CONTROLLER;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.BANK_MANAGEMENT.DAO.BranchDao;
import com.jsp.BANK_MANAGEMENT.DTO.Branch;

@RestController
public class BranchController 
{
	@Autowired
	BranchDao dao;
	
	@PostMapping("/add2")
	public Branch AddEleement(@RequestBody Branch branch , @RequestParam int bank_id)
	{
		return dao.CreateBank(bank_id, branch);
	}
	
	@GetMapping("/add2")
	public Branch GetBranchById(int id)
	{
		return dao.getById(id);
	}
	
	@GetMapping("/all")
	public List<Branch> getAlBranch()
	{
		return dao.getAllBranch();
	}
	
	@DeleteMapping("/del")
	public String deleteBranchId(int id)
	{
		return dao.deleteById(id);
	}
	
	@PutMapping("/upd")
	public Branch updateName(int id, String name)
	{
		return dao.updateBranchName(id, name);
	}



}
