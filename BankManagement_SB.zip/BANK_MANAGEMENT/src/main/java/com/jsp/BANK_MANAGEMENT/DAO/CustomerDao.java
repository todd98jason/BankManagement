package com.jsp.BANK_MANAGEMENT.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.BANK_MANAGEMENT.DTO.Account;
import com.jsp.BANK_MANAGEMENT.DTO.Customer;
import com.jsp.BANK_MANAGEMENT.REPOSITORY.CustomerRepository;

@Repository
public class CustomerDao 
{
	@Autowired
	AccountDao dao;
	
	@Autowired
	CustomerRepository repository;
	
	public Customer createCustomer(int Acc_id, Customer cus )
	{
		Account ac=dao.getAccById(Acc_id);
		List<Customer> list=new ArrayList<Customer>();
		list.add(cus);
		if(ac!=null)
		{
			ac.setCustomer(cus);
			cus.setAccount(ac);
			return repository.save(cus);
		}
		return null;
	}
	
	public Customer getCustomerById(int id)
	{
		Optional<Customer> opt=repository.findById(id);
		if(opt!=null)
		{
			return opt.get();
		}return null;
	}

	public String deleteCustomerById(int id)
	{
		Customer c=getCustomerById(id);
		if(c!=null)
		{
			repository.deleteById(id);
			return "Account deleted successfully...";
		}return"invalid id...";
	}
	
	public Customer updateCustomerNmae(int id,String name)
	{
		Customer c=getCustomerById(id);
		if(c!=null)
		{
			c.setName(name);;
			return repository.save(c);
		}
		
		return null;
	}


}
