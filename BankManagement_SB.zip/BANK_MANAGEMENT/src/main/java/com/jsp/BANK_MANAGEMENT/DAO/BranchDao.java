package com.jsp.BANK_MANAGEMENT.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.BANK_MANAGEMENT.DTO.Bank;
import com.jsp.BANK_MANAGEMENT.DTO.Branch;
import com.jsp.BANK_MANAGEMENT.REPOSITORY.BranchRepository;

@Repository
public class BranchDao 
{
	@Autowired
	BranchRepository repository;
	
	@Autowired
	BankDao dao;
	
	public Branch CreateBank(int bank_id,Branch branch)//1
	{
		//getting the bank object using bANK ID
		Bank b=dao.getBankDetails(bank_id);
		//creating list to store all branches
		List<Branch> branches=new ArrayList<Branch>();
		//adding branch to the list
		branches.add(branch);
		//check if bank exist
		if(b!=null)
		{
			//only if bank exist
			//set branch list to bank
			b.setBranches(branches);
			//and set bank to branch
			branch.setBank(b);
			//store the branch details to DB
			return repository.save(branch);
		}
			return null;

}
	
	public Branch getById(int id)//2
	{
		Optional<Branch> b=repository.findById(id);
		if(b!=null)
		{
			return b.get();
		}
		return null;
	}
	
	public List<Branch> getAllBranch()//3
	{
		return repository.findAll();
	}
	
	public String deleteById(int id)//4
	{
		Branch br=getById(id);
		if(br!=null)
		{
			repository.deleteById(id);;
			
			return "Deleted the  branch data sucessfully...";
		}
		return "Invalid id...";
	}

	public Branch updateBranchName(int id, String name)//5
	{
		Branch br=getById(id);
		if(br!=null)
		{
			br.setBranch_name(name);
			return repository.save(br);	
		}
		return null;
	}


}
