package com.jsp.BANK_MANAGEMENT.REPOSITORY;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.BANK_MANAGEMENT.DTO.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer>
{

}
