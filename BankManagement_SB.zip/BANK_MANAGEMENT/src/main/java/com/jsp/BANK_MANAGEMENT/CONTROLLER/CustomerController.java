package com.jsp.BANK_MANAGEMENT.CONTROLLER;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.BANK_MANAGEMENT.DAO.CustomerDao;
import com.jsp.BANK_MANAGEMENT.DTO.Customer;

@RestController
public class CustomerController 
{
	@Autowired
	CustomerDao dao;
	
	@PostMapping("/add1")
	public Customer addvalue(@RequestParam int id , @RequestBody Customer customer)
	{
		return dao.createCustomer(id , customer);
	}
	
	@GetMapping("/add1")
	public Customer getacId(int id)
	{
		return dao.getCustomerById(id);
	}
	
	@DeleteMapping("/add1")
	public String deletebyid(int id)
	{
		return dao.deleteCustomerById(id);
	}
	
	@PutMapping("/add1")
	public Customer updatename(int id , String name)
	{
		return dao.updateCustomerNmae(id, name);
	}


}
