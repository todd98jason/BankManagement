package com.jsp.BANK_MANAGEMENT.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.BANK_MANAGEMENT.DTO.Account;
import com.jsp.BANK_MANAGEMENT.DTO.Branch;
import com.jsp.BANK_MANAGEMENT.REPOSITORY.AccountRepository;

@Repository
public class AccountDao 
{

	@Autowired
	AccountRepository repository;
	
	@Autowired 
	BranchDao dao;
	
	public Account createAccount(int id, Account acc)
	{
		Branch b=dao.getById(id);
		List<Account> list=new ArrayList<Account>();
		list.add(acc);
		if(b!=null)
		{
			b.setAccounts(list);
			acc.setBranch(b);
			return repository.save(acc);
		}
		return null;
	}
	
	public Account getAccById(int id)
	{
		Optional<Account> opt=repository.findById(id);
		if(opt!=null)
		{
			return opt.get();
		}
		return null;
	}
	
	public String deleteAccById(int id)
	{
		Account a=getAccById(id);
		if(a!=null)
		{
			repository.deleteById(id);
			return "Account deleted successfully...";
		}
		return"invalid id...";
	}
	
	public Account updateAccNmae(int id,String name)
	{
		Account a=getAccById(id);
		if(a!=null)
		{
			a.setAcHolder_name(name);
			return repository.save(a);
		}
		return null;
	}


	
}
