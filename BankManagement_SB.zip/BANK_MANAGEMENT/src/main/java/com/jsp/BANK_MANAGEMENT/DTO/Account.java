package com.jsp.BANK_MANAGEMENT.DTO;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity
public class Account 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ac_id;
	private long ac_no;
	private String acHolder_name;
	private double balance;
	private long ifsccode;
	
	@ManyToOne
	@JoinColumn
	Branch branch;
	
	@OneToOne
	Customer customer;

	public int getAc_id() {
		return ac_id;
	}

	public void setAc_id(int ac_id) {
		this.ac_id = ac_id;
	}

	public long getAc_no() {
		return ac_no;
	}

	public void setAc_no(long ac_no) {
		this.ac_no = ac_no;
	}

	public String getAcHolder_name() {
		return acHolder_name;
	}

	public void setAcHolder_name(String acHolder_name) {
		this.acHolder_name = acHolder_name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public long getIfsccode() {
		return ifsccode;
	}

	public void setIfsccode(long ifsccode) {
		this.ifsccode = ifsccode;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
