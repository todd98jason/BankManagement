package com.jsp.BANK_MANAGEMENT.REPOSITORY;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.BANK_MANAGEMENT.DTO.Branch;

public interface BranchRepository extends JpaRepository<Branch, Integer>
{

}
